const BASE_URL = "https://fakestoreapi.com/products";
