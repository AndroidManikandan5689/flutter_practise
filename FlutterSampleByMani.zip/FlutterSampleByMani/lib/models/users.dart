class Users {
  late int id;
  late String name;
  late int age;
}
